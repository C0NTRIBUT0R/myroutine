# Routine Widget (Kotlin, native AppWidget)

STATUS: source only. NOT compiled or tested (the authoring environment had no Android SDK/Gradle/network).

## Get the APK (pick one)
A) GitHub (no install): create a repo, upload this folder's contents, open Actions > "Build APK" > Run workflow.
   Download artifact "RoutineWidget-debug-apk" (app-debug.apk).
B) Android Studio: File > Open this folder, let Gradle sync (JDK 17), Build > Build APK(s).
   File: app/build/outputs/apk/debug/app-debug.apk

## Install on Vivo Y21T (Android 13)
1. Copy app-debug.apk to the phone and open it.
2. Allow "Install unknown apps" for your file manager/browser when asked, then Install.
3. Open Routine Widget once, check the timetable, tap Save.
4. Vivo: Settings > Battery > Background power consumption > Routine Widget > Allow (or Unrestricted),
   and allow auto-start in i Manager, otherwise Funtouch OS may delay or skip boundary updates.

## Add / resize / remove the widget
Add: long-press empty home screen > Widgets > Routine Widget > drag to the screen.
Resize: long-press the widget, release, drag the edge handles.
Remove: long-press and drag to Remove (or tap Remove). Tapping the widget opens settings.

## Behaviour and limits
- One inexact alarm per class boundary (no exact-alarm permission). Doze/OEM battery limits can delay it by minutes.
  updatePeriodMillis=30 min is a safety net.
- Countdown is a system Chronometer, so it ticks without waking the app; it can briefly show 00:00 until the boundary refresh lands.
- Clock uses TextClock. Widgets cannot run custom animations; the settings screen fades in. No widget config activity or size/appearance option was built.
- Light/dark colours follow the system theme (values-night).
