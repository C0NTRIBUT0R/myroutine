package com.ruhan.routinewidget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import java.util.Calendar
import java.util.Locale

object WidgetRenderer {
    fun build(ctx: Context): RemoteViews {
        val tt = Store.load(ctx)
        val cal = Calendar.getInstance()
        val day = Routine.today(cal)
        val minute = Routine.minuteOfDay(cal)
        val msOfDay = minute * 60_000L + cal.get(Calendar.SECOND) * 1000L + cal.get(Calendar.MILLISECOND)

        val state = Routine.stateAt(tt, day, minute)
        if (Store.hideOutside(ctx) && (state is State.Before || state is State.Finished || state is State.NoClasses)) {
            // Android cannot remove a widget from the home screen; show an empty transparent view instead.
            return RemoteViews(ctx.packageName, R.layout.widget_blank)
        }
        val v = RemoteViews(ctx.packageName, R.layout.widget_routine)
        val dayName = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT, Locale.ENGLISH).uppercase(Locale.ENGLISH)
        v.setTextViewText(R.id.day, "$dayName · MECHANICAL · SEM 1 · B")
        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))

        fun show(id: Int, on: Boolean) = v.setViewVisibility(id, if (on) View.VISIBLE else View.GONE)
        fun timer(label: String, targetMin: Int) {
            val remaining = (targetMin * 60_000L - msOfDay).coerceAtLeast(0L)
            v.setTextViewText(R.id.timer_label, label)
            v.setChronometerCountDown(R.id.timer, true)
            v.setChronometer(R.id.timer, SystemClock.elapsedRealtime() + remaining, null, true)
            show(R.id.timer_box, true)
        }
        fun detail(b: Block) = listOf(b.lesson.code, b.lesson.teacher, Routine.range(b.start, b.end))
            .filter { it.isNotBlank() }.joinToString(" · ")
        fun chips(b: Block) {
            show(R.id.chip_row, true)
            v.setTextViewText(R.id.chip_period, Routine.periods(b))
            val room = b.lesson.location.trim()
            show(R.id.chip_room, room.isNotEmpty())
            v.setTextViewText(R.id.chip_room, room)
        }
        fun next(label: String, b: Block?) {
            show(R.id.next_row, b != null)
            if (b != null) {
                v.setTextViewText(R.id.next_label, label)
                v.setTextViewText(R.id.next_name, b.lesson.subject)
            }
        }

        when (val s = state) {
            is State.Active -> {
                v.setTextViewText(R.id.status, "CURRENT CLASS")
                v.setTextViewText(R.id.subject, s.block.lesson.subject)
                v.setTextViewText(R.id.detail, detail(s.block))
                chips(s.block)
                next(if (s.next != null) "UP NEXT · ${Routine.fmt(s.next.start)}" else "UP NEXT", s.next)
                if (s.next == null) { v.setViewVisibility(R.id.next_row, View.VISIBLE); v.setTextViewText(R.id.next_label, "LAST CLASS TODAY"); v.setTextViewText(R.id.next_name, "Then college finished") }
                timer("ENDS IN", s.block.end)
            }
            is State.Free -> {
                v.setTextViewText(R.id.status, "BREAK")
                v.setTextViewText(R.id.subject, "Free period")
                v.setTextViewText(R.id.detail, "Next class at ${Routine.fmt(s.next.start)}")
                show(R.id.chip_row, false)
                next("UP NEXT · ${Routine.periods(s.next)}", s.next)
                timer("STARTS IN", s.next.start)
            }
            is State.Before -> {
                v.setTextViewText(R.id.status, "BEFORE COLLEGE")
                v.setTextViewText(R.id.subject, "College starts at ${Routine.fmt(s.collegeStart)}")
                v.setTextViewText(R.id.detail, "First class: ${Routine.fmt(s.first.start)}")
                show(R.id.chip_row, false)
                next("FIRST CLASS", s.first)
                timer("COLLEGE IN", s.collegeStart)
            }
            State.Finished -> {
                v.setTextViewText(R.id.status, "DAY COMPLETE")
                v.setTextViewText(R.id.subject, "College finished")
                v.setTextViewText(R.id.detail, "No more classes today")
                show(R.id.chip_row, false); show(R.id.next_row, false)
            }
            State.NoClasses -> {
                v.setTextViewText(R.id.status, "TODAY")
                v.setTextViewText(R.id.subject, "No classes today")
                v.setTextViewText(R.id.detail, "Enjoy your day")
                show(R.id.chip_row, false); show(R.id.next_row, false)
            }
        }
        return v
    }
}
