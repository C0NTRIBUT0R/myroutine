package com.ruhan.routinewidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Lesson(val subject: String = "", val code: String = "", val teacher: String = "", val location: String = "") {
    val isFree: Boolean get() = subject.isBlank()
}

data class Slot(val start: Int, val end: Int) // minutes since midnight

/** days is keyed by Calendar.DAY_OF_WEEK (1 = Sunday ... 7 = Saturday); each list has one Lesson per slot. */
data class Timetable(val slots: List<Slot>, val days: Map<Int, List<Lesson>>)

object Defaults {
    private fun l(s: String, c: String, t: String, r: String) = Lesson(s, c, t, r)
    private val FREE = Lesson()
    private fun ed(r: String) = l("Engineering Drawing", "21011", "AR", r)
    private fun bn(r: String) = l("Bangla-I", "25711", "RH", r)
    private fun en(r: String) = l("English-I", "25712", "SJH", r)
    private fun pe(r: String) = l("Physical Education & Life Skill Development", "25812", "SSH", r)
    private fun ma(r: String) = l("Mathematics-I", "25911", "JR", r)
    private fun ph(r: String) = l("Physics-I", "25912", "FA", r)
    private fun bw(r: String) = l("Basic Workshop Practice", "27011", "MIA", r)
    private fun ms(r: String) = l("Machine Shop Practice-I", "27012", "AR", r)

    val slots = listOf(480 to 525, 525 to 570, 570 to 615, 615 to 660, 660 to 705, 705 to 750, 750 to 795).map { Slot(it.first, it.second) }

    // Read from the Semester 1 Group B routine photo (class start 11/10/2026).
    val timetable = Timetable(slots, mapOf(
        Calendar.SUNDAY to listOf(ph("1005"), en("1005"), ma("1005"), ma("1005"), ed("309"), ed("309"), ed("309")),
        Calendar.MONDAY to listOf(ms("Machine Shop"), ms("Machine Shop"), ms("Machine Shop"), bn("Machine Shop"), pe("Field"), pe("Field"), pe("Field")),
        Calendar.TUESDAY to listOf(ed("309"), ed("309"), ed("309"), en("1005"), ms("1005"), ph("1005"), ph("1005")),
        Calendar.WEDNESDAY to listOf(ma("RA-2"), ma("RA-2"), ph("Phy/Lab"), ph("Phy/Lab"), ms("Welding Shop"), ms("Welding Shop"), ms("Welding Shop")),
        Calendar.THURSDAY to listOf(bw("Welding Shop"), bw("Welding Shop"), bw("Welding Shop"), ma("Patt/S"), ma("Patt/S"), bn("Patt/S"), ph("Patt/S")),
        Calendar.FRIDAY to List(7) { FREE },
        Calendar.SATURDAY to List(7) { FREE }
    ))
}

object Store {
    private const val PREFS = "routine"; private const val KEY = "timetable_v3"

    fun load(ctx: Context): Timetable {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return Defaults.timetable
        return runCatching { parse(raw) }.getOrNull() ?: Defaults.timetable
    }

    fun save(ctx: Context, tt: Timetable) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, toJson(tt)).apply()
    }

    fun hideOutside(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("hide_outside", true)
    fun setHideOutside(ctx: Context, v: Boolean) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("hide_outside", v).apply() }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    private fun toJson(tt: Timetable): String {
        val o = JSONObject()
        o.put("slots", JSONArray().also { a -> tt.slots.forEach { a.put(JSONArray().put(it.start).put(it.end)) } })
        val d = JSONObject()
        tt.days.forEach { (day, ls) ->
            d.put(day.toString(), JSONArray().also { a ->
                ls.forEach { a.put(JSONObject().put("s", it.subject).put("c", it.code).put("t", it.teacher).put("l", it.location)) }
            })
        }
        o.put("days", d)
        return o.toString()
    }

    private fun parse(raw: String): Timetable {
        val o = JSONObject(raw)
        val sa = o.getJSONArray("slots")
        val slots = List(sa.length()) { Slot(sa.getJSONArray(it).getInt(0), sa.getJSONArray(it).getInt(1)) }
        val d = o.getJSONObject("days")
        val days = (1..7).associateWith { day ->
            val a = d.optJSONArray(day.toString())
            List(slots.size) { i ->
                val x = a?.optJSONObject(i)
                if (x == null) Lesson() else Lesson(x.optString("s"), x.optString("c"), x.optString("t"), x.optString("l"))
            }
        }
        return Timetable(slots, days)
    }
}
