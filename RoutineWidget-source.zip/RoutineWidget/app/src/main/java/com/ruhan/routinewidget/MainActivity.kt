package com.ruhan.routinewidget

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val days = mutableMapOf<Int, MutableList<Lesson>>()
    private val startFields = mutableListOf<EditText>()
    private val endFields = mutableListOf<EditText>()
    private val lessonFields = mutableListOf<List<EditText>>() // per period: subject, code, teacher, room
    private var currentDay = Routine.today()
    private var slotCount = 7

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun field(hint: String, text: String, weight: Float = 1f): EditText = EditText(this).apply {
        this.hint = hint; setText(text); setSingleLine(true); textSize = 14f
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight)
    }

    private fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tt = Store.load(this)
        slotCount = tt.slots.size
        for (d in 1..7) days[d] = (tt.days[d] ?: List(slotCount) { Lesson() }).toMutableList()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(24)) }
        root.addView(label("Routine settings", 22f, true))
        root.addView(label("Timetable was read from your routine photo. Please double-check it, then tap Save. " +
            "Leave Subject empty for a free period.", 12f).apply { setPadding(0, dp(6), 0, dp(12)) })

        val hide = CheckBox(this).apply {
            text = "Hide widget outside class hours (blank before the first class, after the last class, and on days with no classes)"
            isChecked = Store.hideOutside(this@MainActivity)
            setOnCheckedChangeListener { _, on -> Store.setHideOutside(this@MainActivity, on); RoutineWidgetProvider.refresh(this@MainActivity) }
        }
        root.addView(hide)

        root.addView(label("Period times (24-hour, HH:mm)", 15f, true).apply { setPadding(0, dp(12), 0, 0) })
        for (i in 0 until slotCount) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            val s = field("08:00", hhmm(tt.slots[i].start)); val e = field("08:45", hhmm(tt.slots[i].end))
            row.addView(label("P${i + 1}  ").apply { minWidth = dp(40) }); row.addView(s); row.addView(label(" – ")); row.addView(e)
            startFields += s; endFields += e; root.addView(row)
        }

        root.addView(label("Day", 15f, true).apply { setPadding(0, dp(16), 0, 0) })
        val names = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names) }
        spinner.setSelection(currentDay - 1, false)
        root.addView(spinner)

        for (i in 0 until slotCount) {
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, 0) }
            card.addView(label("Period ${i + 1}", 13f, true))
            val a = field("Subject", ""); val b = field("Code", ""); val c = field("Teacher", ""); val d = field("Room / workshop", "")
            card.addView(LinearLayout(this).apply { addView(a, LinearLayout.LayoutParams(0, -2, 2f)); addView(b, LinearLayout.LayoutParams(0, -2, 1f)) })
            card.addView(LinearLayout(this).apply { addView(c, LinearLayout.LayoutParams(0, -2, 1f)); addView(d, LinearLayout.LayoutParams(0, -2, 2f)) })
            lessonFields += listOf(a, b, c, d); root.addView(card)
        }
        bindDay()

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { commitDay(); currentDay = pos + 1; bindDay() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val save = Button(this).apply { text = "Save"; setOnClickListener { save() } }
        val reset = Button(this).apply { text = "Reset to transcribed timetable"; setOnClickListener {
            Store.reset(this@MainActivity); RoutineWidgetProvider.refresh(this@MainActivity); recreate() } }
        root.addView(save); root.addView(reset)

        setContentView(ScrollView(this).apply { addView(root) })
        root.alpha = 0f; root.animate().alpha(1f).setDuration(350).start()
    }

    private fun hhmm(m: Int) = "${(m / 60).toString().padStart(2, '0')}:${(m % 60).toString().padStart(2, '0')}"

    private fun parse(s: String): Int? {
        val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(s.trim()) ?: return null
        val h = m.groupValues[1].toInt(); val min = m.groupValues[2].toInt()
        return if (h in 0..23 && min in 0..59) h * 60 + min else null
    }

    private fun bindDay() {
        val ls = days[currentDay]!!
        for (i in 0 until slotCount) {
            val l = ls.getOrElse(i) { Lesson() }; val f = lessonFields[i]
            f[0].setText(l.subject); f[1].setText(l.code); f[2].setText(l.teacher); f[3].setText(l.location)
        }
    }

    private fun commitDay() {
        days[currentDay] = MutableList(slotCount) { i ->
            val f = lessonFields[i]
            Lesson(f[0].text.toString().trim(), f[1].text.toString().trim(), f[2].text.toString().trim(), f[3].text.toString().trim())
        }
    }

    private fun save() {
        commitDay()
        val slots = mutableListOf<Slot>()
        for (i in 0 until slotCount) {
            val s = parse(startFields[i].text.toString()); val e = parse(endFields[i].text.toString())
            val prevEnd = slots.lastOrNull()?.end ?: 0
            if (s == null || e == null || s >= e || s < prevEnd) {
                Toast.makeText(this, "Check period ${i + 1} times (HH:mm, start before end, no overlap)", Toast.LENGTH_LONG).show(); return
            }
            slots += Slot(s, e)
        }
        Store.save(this, Timetable(slots, days.mapValues { it.value.toList() }))
        RoutineWidgetProvider.refresh(this)
        Toast.makeText(this, "Saved. Widget updated.", Toast.LENGTH_SHORT).show()
    }
}
