package com.ruhan.routinewidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import java.util.Calendar

class RoutineWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = refresh(context)
    override fun onEnabled(context: Context) = refresh(context)
    override fun onDisabled(context: Context) = cancel(context)

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action in REFRESH_ACTIONS) refresh(context)
    }

    companion object {
        private const val ACTION_UPDATE = "com.ruhan.routinewidget.UPDATE"
        private val REFRESH_ACTIONS = setOf(
            ACTION_UPDATE, Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED, Intent.ACTION_DATE_CHANGED, Intent.ACTION_MY_PACKAGE_REPLACED
        )

        private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
            ctx, 919, Intent(ctx, RoutineWidgetProvider::class.java).setAction(ACTION_UPDATE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, RoutineWidgetProvider::class.java))
            if (ids.isEmpty()) { cancel(ctx); return }
            mgr.updateAppWidget(ids, WidgetRenderer.build(ctx))
            schedule(ctx)
        }

        private fun cancel(ctx: Context) {
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx))
        }

        /** One inexact, doze-friendly alarm for the next class boundary (or the next midnight). No exact-alarm permission needed. */
        private fun schedule(ctx: Context) {
            val tt = Store.load(ctx)
            val now = Calendar.getInstance()
            val boundary = Routine.nextBoundary(tt, Routine.today(now), Routine.minuteOfDay(now))
            val target = Calendar.getInstance().apply {
                if (boundary == null) { add(Calendar.DAY_OF_YEAR, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }
                else { set(Calendar.HOUR_OF_DAY, boundary / 60); set(Calendar.MINUTE, boundary % 60) }
                set(Calendar.SECOND, 1); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pending(ctx))
        }
    }
}
