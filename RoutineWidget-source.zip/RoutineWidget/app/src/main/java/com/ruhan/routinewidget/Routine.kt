package com.ruhan.routinewidget

import java.util.Calendar

/** A run of consecutive periods with the same subject, shown as one class. */
data class Block(val first: Int, val last: Int, val lesson: Lesson, val start: Int, val end: Int)

sealed class State {
    object NoClasses : State()
    data class Before(val collegeStart: Int, val first: Block) : State()
    data class Active(val block: Block, val next: Block?) : State()
    data class Free(val next: Block) : State()
    object Finished : State()
}

object Routine {
    private fun same(a: Lesson, b: Lesson) =
        a.subject.trim().equals(b.subject.trim(), true) && a.code.trim().equals(b.code.trim(), true)

    fun blocks(tt: Timetable, day: Int): List<Block> {
        val lessons = tt.days[day] ?: return emptyList()
        val n = minOf(tt.slots.size, lessons.size)
        val out = mutableListOf<Block>()
        var i = 0
        while (i < n) {
            val l = lessons[i]
            if (l.isFree) { i++; continue }
            var j = i
            while (j + 1 < n && same(lessons[j + 1], l) && tt.slots[j + 1].start == tt.slots[j].end) j++
            out += Block(i, j, l, tt.slots[i].start, tt.slots[j].end)
            i = j + 1
        }
        return out
    }

    fun stateAt(tt: Timetable, day: Int, minute: Int): State {
        val b = blocks(tt, day)
        if (b.isEmpty() || tt.slots.isEmpty()) return State.NoClasses
        if (minute < tt.slots.first().start) return State.Before(tt.slots.first().start, b.first())
        b.firstOrNull { minute >= it.start && minute < it.end }?.let { cur ->
            return State.Active(cur, b.firstOrNull { it.start >= cur.end })
        }
        val next = b.firstOrNull { it.start > minute } ?: return State.Finished
        return State.Free(next)
    }

    /** Minute-of-day of the next moment the displayed state can change today, or null if none (next change is midnight). */
    fun nextBoundary(tt: Timetable, day: Int, minute: Int): Int? {
        val pts = blocks(tt, day).flatMap { listOf(it.start, it.end) } + (tt.slots.firstOrNull()?.start ?: -1)
        return pts.filter { it > minute }.minOrNull()
    }

    fun today(cal: Calendar = Calendar.getInstance()) = cal.get(Calendar.DAY_OF_WEEK)
    fun minuteOfDay(cal: Calendar = Calendar.getInstance()) = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

    fun fmt(min: Int): String {
        val h = min / 60; val m = min % 60
        return "${if (h % 12 == 0) 12 else h % 12}:${m.toString().padStart(2, '0')} ${if (h >= 12) "PM" else "AM"}"
    }

    fun range(a: Int, b: Int): String {
        val fa = fmt(a); val fb = fmt(b)
        return if (fa.takeLast(2) == fb.takeLast(2)) "${fa.dropLast(3)} – $fb" else "$fa – $fb"
    }

    fun periods(b: Block) = if (b.first == b.last) "Period ${b.first + 1}" else "Period ${b.first + 1}–${b.last + 1}"
}
